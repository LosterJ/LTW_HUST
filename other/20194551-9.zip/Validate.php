<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $email = $_POST["email"];
        $url = $_POST["url"];
        $phone = $_POST["phone"];
        if (preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/i", $email)) {
            print "Valid email address = $email <br>";
        } else {
            print "Invalid email address = $email <br>";
        }
        if (preg_match("%^((https?://)|(www\.))([a-z0-9-].?)+(:[0-9]+)?(/.*)?$%i", $url)) {
            print "Valid URL address = $url <br>";
        } else {
            print "Invalid URL address = $url <br>";
        }
        if (preg_match("/(03|05|07|08|09|01[2|6|8|9])+([0-9]{8})\b/", $phone)) {
            print "Valid phone number = $phone <br>";
        } else {
            print "Invalid phone number = $phone <br>";
        }
    ?>
</body>
</html>