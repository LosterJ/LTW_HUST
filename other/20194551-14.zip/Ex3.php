<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form name="RegForm" onsubmit="return validate()" action="" method="POST">
    <input type="hidden" name="sent" value="1" />
    <table>
        <tr>
            <td>Username:</td>
            <td><input type="text" name="username" placeholder="Enter username" value="<?= @ $_POST['username'] ?>" /></td>
        </tr>
        <tr>
            <td>Gender:</td>
            <td>
                <input type="radio" id="male" name="gender" value="male" checked>
                <label for="male">Male</label>
                <input type="radio" id="female" name="gender" value="female">
                <label for="female">Female</label>
            </td>
        </tr>
        <tr>
            <td>Email:</td>
            <td><input type="email" name="email" placeholder="email@address.com" value="<?= @ $_POST['email'] ?>" /></td>
        </tr>
        <tr>
            <td>Phone Number:</td>
            <td><input type="tel" name="phone" placeholder="0123456789" value="<?= @ $_POST['phone'] ?>" /></td>
        </tr>
        <tr>
            <td>Date of Birth:</td>
            <td><input type="date" name="date" value="<?= @ $_POST['date'] ?>" required></td>
        </tr>
        <tr>
            <td>
                <p>
                    <button type="submit">Submit</button>
                </p>
            </td>
        </tr>
    </table>
</form>

</body>
</html>
<script>
function validate() {
    var name = document.forms.RegForm.username.value;
    var email = document.forms.RegForm.email.value;
    var phone = document.forms.RegForm.phone.value;
    var regEmail=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/g;
    var regPhone=/^\d{10}$/;
    var regName = /\d+$/g;

    if (name == "" || regName.test(name)) {
        window.alert("Please enter your name properly.");
        name.focus();
        return false;
    }
        
    if (email == "" || !regEmail.test(email)) {
        window.alert("Please enter a valid e-mail address.");
        email.focus();
        return false;
    }
        
    if (phone == "" || !regPhone.test(phone)) {
        alert("Please enter valid phone number.");
        phone.focus();
        return false;
    }

    return true;
}
</script>