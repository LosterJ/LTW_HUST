<?php  
    $conn = mysqli_connect("localhost", "root", "", "testing");
    $query = 'create table if not exists products(' .
    'product_id int primary key auto_increment,' .
    'product_name varchar(255) not null)';
    $conn->query($query);
    $query = "SELECT * FROM `products` LIMIT 1";
    $result = $conn->query($query);

    if (!($obj = $result->fetch_object()))
    {
        $query = "INSERT INTO products (product_name)
                VALUES  ('iPhone 13 | Chính hãng VN/A'),
                        ('iPhone 13 Pro Max | Chính hãng VN/A'),
                        ('Samsung Galaxy Note 20 Ultra 5G'),
                        ('Samsung Galaxy Z Flip3 5G'),
                        ('Samsung Galaxy A52'),
                        ('Apple MacBook Pro 13 Touch Bar M1 256GB 2020'),
                        ('Xiaomi Mi 11 Lite 5G'),
                        ('Laptop Dell Vostro 3405 V4R53500U003W'),
                        ('Vivo X70 Pro 5G')";
        $conn->query($query);
    }

    if(isset($_POST["query"]))  
    {  
        $output = '';  
        $query = "SELECT * FROM products WHERE product_name LIKE '%".$_POST["query"]."%'";  
        $result = mysqli_query($conn, $query);  
        $output = '<ul class="list-unstyled">';  
        if(mysqli_num_rows($result) > 0)  
        {  
            while($row = mysqli_fetch_array($result))  
            {  
                $output .= '<li>'.$row["product_name"].'</li>';  
            }  
        }  
        else  
        {  
            $output .= '<li>Product Not Found</li>';  
        }  
        $output .= '</ul>';
        echo $output;  
    }  
?> 